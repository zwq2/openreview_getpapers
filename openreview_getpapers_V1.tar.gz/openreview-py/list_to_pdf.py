from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
import textwrap

def create_pdf(filename, data_list):
    # 创建 A4 大小的 PDF
    c = canvas.Canvas(filename, pagesize=A4)

    # 设置字体和字号
    c.setFont("Helvetica", 10)  # 调整字体大小

    # 在页面上绘制文本，可以调整坐标和内容
    x, y = 50, A4[1] - 100  # 调整起始坐标
    line_height = 12  # 设置行高

    for data_dict in data_list:
        for key, value in data_dict.items():
            # 拼接键值对
            text = f"{key}: {value}"

            # 手动处理换行
            lines = textwrap.wrap(text, width=85)  # 调整宽度
            for line in lines:
                c.drawString(x, y, line)
                y -= line_height  # 调整行间距
                if y < 100:
                    c.showPage()
                    y = A4[1] - 100  # 重新设置起始纵坐标

            

            # 到达页面底部时开始新的一页
            if y < 100:
                c.showPage()
                y = A4[1] - 100  # 重新设置起始纵坐标
        # 添加留空白
        y -= line_height  # 调整字典之间的空白

    # 保存 PDF 文件
    c.save()

# # 示例用法
# data_list = [
#     {'Name': 'John', 'Abstract': 'This is a long abstract text that needs to be wrapped to fit the page.', 'Occupation': 'Engineer'},
#     {'Name': 'Alice', 'Abstract': 'Another abstract for Alice with a lot of content. This needs to be wrapped as well.', 'Occupation': 'Designer'},
#     {'Name': 'Bob', 'Abstract': 'Abstract for Bob. More text to see how it wraps on the page. This should not overflow.', 'Occupation': 'Teacher'}
# ]

# create_pdf('output.pdf', data_list)
