'''
Description: 从 openreview 获取被接收的顶会论文保存至数据库
Version: 1.0
Author: Glenn
Email: chenluda01@outlook.com
Date: 2023-05-04 13:45:40
FilePath: \12-arxivdownload\main.py
Copyright (c) 2023 by Kust-BME, All Rights Reserved. 
'''

"""
@Description :   理解，修改；调参；增加关键词搜索；2022版本，已经正式发布的
@Author      :   Wanqi Zhou, XJTU, RIKEN
@Time        :   2023/11/08 
Copyright (c) 2023 by ZWQ, All Rights Reserved. 
"""
import openreview
import time
from pyzotero import zotero
import wget




def get_papers_from_openreview(conference_id,keywords=None,download=True,path_outdir=None):
    """
    从 openreview 获取被接收的顶会论文
    """
    def get_accepted_forum_ids(blind_notes):
        """
        从提交的论文中获取被接收的论文
        """
        forum_ids = set()
        for note in blind_notes:
            for reply in note.details["directReplies"]:
                if reply["invitation"].endswith("Decision") and 'Accept' in reply["content"]['decision']:
                    forum_ids.add(reply['forum'])
        return forum_ids

    def format_note(note, conference_name):
        """
        获取需要存储的论文信息
        """
        authors_string = ','.join(note.content['authors'])
        tags_string = ','.join(note.content['keywords'])
        localTime = time.localtime(note.pdate/1000)
        strTime = time.strftime('%Y-%m-%d', localTime)

        return {
            'title': note.content['title'],
            'url': 'https://openreview.net/forum?id=' + note.forum,
            'pub_date': strTime,
            'summary': note.content['abstract'],
            'authors': authors_string,
            'tags': tags_string,
            'read_num': 0,
            'conference': conference_name,
            'venue': note.content['venue']
        }
    def forum_pdf_get(note,pdf_outdir=path_outdir):
        import os
        pdf_binary = client.get_pdf(note.forum)
        if not os.path.exists(pdf_outdir):
            os.makedirs(pdf_outdir)
        title = note.content['title'].strip('"')
        pdf_outfile = os.path.join(pdf_outdir, '{}.pdf'.format(title))
        
        with open(pdf_outfile, 'wb') as file_handle:
                file_handle.write(pdf_binary)
        print('下载论文..')
        return

   
    submissions = client.get_all_notes(
        invitation=conference_id + '/Conference/-/Blind_Submission', details='directReplies')
   
    
   
    # 从提交的论文中获取被接收论文的 id
    accepted_forum_ids = get_accepted_forum_ids(submissions)
    # 通过 id 获取需要存储的论文信息
    def has_shared_word(list1, list2):
        words_list1 = set(word.lower() for phrase in list1 for word in phrase.split())
        words_list2 = set(word.lower() for phrase in list2 for word in phrase.split())
        
        return bool(words_list1.intersection(words_list2))
       
    if keywords:
        notes_list = [format_note(note, conference_name) for note in submissions if note.forum in accepted_forum_ids and has_shared_word(keywords,note.content['keywords'])]
    else:
        notes_list = [format_note(note, conference_name) for note in submissions if note.forum in accepted_forum_ids]
    if download:
        if keywords:
            count_papers=[forum_pdf_get(note) for note in submissions if note.forum in accepted_forum_ids and has_shared_word(keywords,note.content['keywords'])]
        else:
            count_papers = [forum_pdf_get(note) for note in submissions if note.forum in accepted_forum_ids]
    count_papers_value = len(count_papers)
    return notes_list,count_papers_value


def insert_papers_to_db(papers):
    """
    将获取的论文信息保存至zetero数据库
    参考链接：https://cloud.tencent.com/developer/article/1769629
    """

    # 创建 Zotero 实例
    library_id = 'xxx' #那串数字
    library_type = 'user'  # 或 'group'，取决于您的 Zotero 帐户类型
    api_key = 'xxx'
    zot = zotero.Zotero(library_id, library_type, api_key)
    for paper in papers:
            
        # 论文信息
        # item_type = 'conference'
        title = paper['title']
        creators = paper['authors']
        tags = [paper['tags']]  # 可以包含多个关键字
        url = paper['url']
        abstract = paper['summary']
        venue = paper['venue']
        date = paper['pub_date']

        # 创建论文条目
        # new_item = zot.item_template(item_type, title, creators)
        # new_item = zot.item_template(item_type)
        new_item ={}
        new_item['title'] = title
        new_item['creators'] = [creators]
        new_item['tags'] = tags
        new_item['url'] = url
        new_item['abstractNote'] =abstract
        new_item['accessDate'] = date 
        new_item['extra'] = venue


        # 添加论文条目到 Zotero
        zot.create_items([new_item])
        # pdf_link = url.replace('forum', 'pdf')
        # # 指定下载文件夹位置
        # download_directory = '/home/data-3/wanqi/papers/test/'

        # # 拼接完整的保存路径
        # output_file = download_directory + 'output.pdf'

        # # 下载文件到指定文件夹
        # wget.download(pdf_link, out=output_file)


    print("论文已添加到 Zotero。")

if __name__ == '__main__':
    # 如果是2022 之前：
    client = openreview.Client(baseurl='https://api.openreview.net')
    

    conference_name = 'NeurIPS'
    conference_year = '2022'
    # keywords=['defense','3D Object Detection'] #关于这两个中的任何一个满足都会下载，后续可以设计多种关键词搜索约束方式
    keywords=None
    # 'NeurIPS.cc/2023'
    pdf_filepath = '/home/data-3/wanqi/papers/test/' #路径只由这个决定
    
    paper_list = get_papers_from_openreview(
        conference_name + '.cc/' + conference_year,keywords=keywords,path_outdir=pdf_filepath,download=True)
    
    pass
    print(1)
    
    # if paper_list:
    #     insert_papers_to_db(paper_list)
    # else:
    #     print("No papers found to insert into the database.")