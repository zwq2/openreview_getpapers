"""
@Description :   2023版本,主要是刚刚发布情况的，并没有正式公开,但是这个时候notes都是被录取的
@Author      :   Wanqi Zhou, XJTU, RIKEN
@Time        :   2023/11/08 22:09:11
@代码关键： 
1. 要了解需要用哪个note V1还是V2
2. 要了解自己需要爬虫的论文状态下的notes的invitation怎么写 可以参考“在代码里搜索论文的名字 仔细观察这个库是怎么写的”
3. 要去看note下变量的特点 是否与自己的需求对应
"""

#2023
from  openreview.api import *
import time
from pyzotero import zotero
import wget
from list_to_pdf import *




def get_papers_from_openreview(conference_id,keywords=None,download=True,path_outdir=None):
    """
    从 openreview 获取被接收的顶会论文,但并没有正式被官网发布
    """
    # "关键"词搜索
    def has_shared_word(list1, list2):
        words_list1 = set(word.lower() for phrase in list1 for word in phrase.split())
        words_list2 = set(word.lower() for phrase in list2 for word in phrase.split())
        
        return bool(words_list1.intersection(words_list2))
    
    def get_accepted_forum_ids(blind_notes):
        # """
        # 获取formu_id,这个id是链接很多信息的
        # """
        forum_ids = set()
        for note in blind_notes:
            # 因为这个状态都是接收的，因此直接add
            forum_ids.add(note.forum)
        return forum_ids
       
    def format_note(note, conference_name):
        """
        获取需要存储的论文信息
        """
        authors_string = ','.join(note.content['authors']['value'])
        tags_string = ','.join(note.content['keywords']['value'])
        localTime = time.localtime(note.pdate/1000)
        strTime = time.strftime('%Y-%m-%d', localTime)

        return {
            'title': note.content['title']['value'],
            'url': 'https://openreview.net/forum?id=' + note.forum,
            'pub_date': strTime,
            'summary': note.content['abstract'],
            'authors': authors_string,
            'tags': tags_string,
            'read_num': 0,
            'conference': conference_name,
            'venue': note.content['venue']['value']
            
        }
    def forum_pdf_get(note,pdf_outdir=path_outdir):
        import os
        pdf_binary = client.get_pdf(note.forum)
        pdf_outdir = pdf_outdir + conference_name +'/'
        if keywords:
            pdf_outdir = pdf_outdir + '_'.join(keywords) +'/'
        status = note.content['venue']['value']
        if has_shared_word(['poster'],[status]):
            pdf_outdir = pdf_outdir + 'Poster' + '/'
        if has_shared_word(['oral'],[status]):
            pdf_outdir = pdf_outdir + 'Oral' + '/'
        if has_shared_word(['spotlight'],[status]):
            pdf_outdir = pdf_outdir + 'Spotlight' + '/'
        
        if not os.path.exists(pdf_outdir):
            os.makedirs(pdf_outdir)
        title = note.forum
        pdf_outfile = os.path.join(pdf_outdir, '{}.pdf'.format(title))
        
        with open(pdf_outfile, 'wb') as file_handle:
                file_handle.write(pdf_binary)

        print('下载论文..')
        
        return 


    submissions = client.get_all_notes(
    invitation=conference_id + '/Conference/-/Submission', details='directReplies')

    # 获取论文的 id
    accepted_forum_ids = get_accepted_forum_ids(submissions)
   
    

       
    if keywords:
        notes_list = [format_note(note, conference_name) for note in submissions if note.forum in accepted_forum_ids and has_shared_word(keywords,note.content['keywords']['value'])]
    else:
        notes_list = [format_note(note, conference_name) for note in submissions if note.forum in accepted_forum_ids]
    if download:
        if keywords:
            count_papers = [forum_pdf_get(note) for note in submissions if note.forum in accepted_forum_ids and has_shared_word(keywords,note.content['keywords']['value'])]
        else:
            count_papers = [forum_pdf_get(note) for note in submissions if note.forum in accepted_forum_ids]
        count_papers_value = len(count_papers)
    return notes_list,count_papers_value




if __name__ == '__main__':
   
    client = OpenReviewClient(baseurl='https://api2.openreview.net')
    print(client.notes_url)

    conference_name = 'NeurIPS'
    conference_year = '2023'
   
    # keywords=None
    keywords=['LLM','Robot']
 
    # 'NeurIPS.cc/2023'
    pdf_filepath = '/home/data-3/wanqi/papers/'
    
    paper_list,count = get_papers_from_openreview(
        conference_name + '.cc/' + conference_year,keywords=keywords,path_outdir=pdf_filepath,download=True)
    
    print(count)
    # 构建摘要相关的pdf
    if paper_list:
        if keywords:
            create_pdf(pdf_filepath+conference_name+'/'+'{}.pdf'.format('_'.join(keywords)),paper_list)
        else:
            create_pdf(pdf_filepath+conference_name+'/'+'summary.pdf',paper_list)