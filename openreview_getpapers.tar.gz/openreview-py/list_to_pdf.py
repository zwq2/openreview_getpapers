from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4

def create_pdf(filename, data_list):
    # 创建 A4 大小的 PDF
    c = canvas.Canvas(filename, pagesize=A4)

    # 设置字体和字号
    c.setFont("Helvetica", 12)

    # 在页面上绘制文本，可以调整坐标和内容
    x, y = 100, A4[1] - 100  # 调整起始坐标
    for data_dict in data_list:
        for key, value in data_dict.items():
            text = f"{key}: {value}"
            c.drawString(x, y, text)
            y -= 20  # 调整行间距

    # 保存 PDF 文件
    c.save()


